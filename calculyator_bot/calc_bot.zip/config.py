# -*- coding: utf-8 -*-
token = "5075110428:AAFnKAdF_9aeiOhvg1qnDy70D0GssHL15vE" 
